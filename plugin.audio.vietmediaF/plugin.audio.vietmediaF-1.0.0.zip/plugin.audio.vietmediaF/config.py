VIETMEDIA_HOST = "http://vietmediaf.net/kodi_audio.php"
