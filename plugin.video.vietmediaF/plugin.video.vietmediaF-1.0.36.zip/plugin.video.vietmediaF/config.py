VIETMEDIA_HOST = "http://vietmediaf.net/kodi.php"
