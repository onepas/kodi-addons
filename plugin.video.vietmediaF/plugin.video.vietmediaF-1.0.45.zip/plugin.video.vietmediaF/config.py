VIETMEDIA_HOST = "http://vietmediaf.net/kodi-dev.php"
