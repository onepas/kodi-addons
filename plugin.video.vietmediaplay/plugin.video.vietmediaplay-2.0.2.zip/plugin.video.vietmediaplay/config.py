#VIETMEDIA_HOST = "http://localhost:3000"
VIETMEDIA_HOST = "http://api.vietmedia.kodi.vn"
